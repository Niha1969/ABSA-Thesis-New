"""Merge exported Label Studio JSON and split into train/val/test for ABSA."""
import json, random
import pandas as pd
from pathlib import Path
from loguru import logger
from ..config import get_settings
from ..utils import ensure_dir

def main(export_jsonl: str):
    cfg = get_settings()
    out_dir = ensure_dir("artifacts/absa")

    rows = []
    with open(export_jsonl, "r", encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            text = rec.get("text") or rec.get("data", {}).get("text")
            # Expect predictions under 'annotations' or 'result'
            aspect = rec.get("aspect") or rec.get("result", [{}])[0].get("value", {}).get("choices", [None])[0]
            polarity = rec.get("polarity") or rec.get("result", [{}])[1].get("value", {}).get("choices", [None])[0]
            if text and aspect and polarity:
                rows.append({"sentence": text, "aspect": aspect, "polarity": polarity})

    if not rows:
        logger.error("No labeled rows found. Check your export format.")
        return

    df = pd.DataFrame(rows).dropna().drop_duplicates()
    logger.info(f"Merged {len(df)} labeled sentences.")

    # Stratified-ish split by aspect
    random.seed(13)
    df = df.sample(frac=1.0, random_state=13).reset_index(drop=True)

    n = len(df)
    n_train, n_val = int(0.8*n), int(0.1*n)
    train, val, test = df.iloc[:n_train], df.iloc[n_train:n_train+n_val], df.iloc[n_train+n_val:]

    train.to_csv(cfg["modeling"]["absa_train_file"], index=False)
    val.to_csv(cfg["modeling"]["absa_val_file"], index=False)
    test.to_csv(cfg["modeling"]["absa_test_file"], index=False)

    logger.info("Saved train/val/test to artifacts/absa/")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("export_jsonl", type=str, help="Path to Label Studio export JSONL")
    args = ap.parse_args()
    main(args.export_jsonl)
