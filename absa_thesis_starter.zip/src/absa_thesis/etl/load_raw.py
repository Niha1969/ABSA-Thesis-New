"""Load raw sample files (or user-provided files) into a canonical schema."""
import pandas as pd
from pathlib import Path
from loguru import logger
from ..config import get_settings
from ..utils import ensure_dir

def main():
    cfg = get_settings()
    raw_dir = ensure_dir(cfg.paths["raw_dir"])
    clean_dir = ensure_dir(cfg.paths["clean_dir"])

    # Load samples if the user hasn't added raw files yet
    amazon_p = Path(cfg.data["sample_files"]["amazon_jsonl"])
    gplay_p = Path(cfg.data["sample_files"]["gplay_csv"])

    rows = []
    if amazon_p.exists():
        df_a = pd.read_json(amazon_p, lines=True)
        rows.append(df_a)
        logger.info(f"Loaded Amazon sample: {len(df_a)} rows")
    if gplay_p.exists():
        df_g = pd.read_csv(gplay_p)
        rows.append(df_g)
        logger.info(f"Loaded GPlay sample: {len(df_g)} rows")

    if not rows:
        logger.warning("No sample files found. Add data to data/data_raw and rerun.")
        return

    df = pd.concat(rows, ignore_index=True)
    # Canonical columns
    df = df.rename(columns={
        "review_id": "review_id",
        "source_id": "source_id",
        "text": "text",
        "rating": "rating",
        "date": "date",
        "platform": "platform",
    })[["platform","source_id","rating","date","text"]]

    out = raw_dir / "reviews_raw.parquet"
    df.to_parquet(out, index=False)
    logger.info(f"Wrote {out} with {len(df)} rows.")

if __name__ == "__main__":
    main()
