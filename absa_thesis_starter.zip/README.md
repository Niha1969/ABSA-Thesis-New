# ABSA Thesis: Customer Feedback Mining & Product Improvement Dashboard

A pragmatic, reproducible starter repo for a near real-time Voice-of-Customer pipeline combining:
- Transformer ABSA (RoBERTa) with domain adaptation
- Association-rule mining (Apriori) for actionable patterns
- Streamlit dashboard for insight delivery
- SUS-based usability evaluation

This repo is designed to be runnable end-to-end with sample data, then swap in real datasets when ready.
